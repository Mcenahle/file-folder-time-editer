﻿'本程序是自由软件：你可以再分发之和/或依照由自由软件基金会发布的 GNU 通用公共许可证修改之，无论是版本 3 许可证，还是（按你的决定）任何以后版都可以。
'发布该程序是希望它能有用， 但是并无保障；甚至连可销售和符合某个特定的目的都不保证。请参看 GNU 通用公共许可证， 了解详情。
'你应该随程序获得一份 GNU 通用公共许可证的复本。如果没有，请看 <https://www.gnu.org/licenses/>。

Imports System.IO

Public Class Form1
    Private Sub RadioButton1_Checked(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        TextBox1.Enabled = True
        TextBox2.Enabled = False
        TextBox4.Enabled = False
    End Sub

    Private Sub RadioButton2_Checked(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        TextBox1.Enabled = False
        TextBox2.Enabled = True
        TextBox4.Enabled = True
    End Sub

    Private Sub TextBox1_DragDrop(sender As Object, e As DragEventArgs) Handles TextBox1.DragDrop
        ' 检查拖放的数据是否是文件夹
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            ' 获取拖放的文件夹路径
            Dim folderPath As String = CType(e.Data.GetData(DataFormats.FileDrop), String())(0)

            ' 如果是文件夹路径，则在TextBox1中显示绝对路径
            If IO.Directory.Exists(folderPath) Then
                TextBox1.Text = folderPath
            End If
        End If
    End Sub

    Private Sub TextBox1_DragEnter(sender As Object, e As DragEventArgs) Handles TextBox1.DragEnter
        ' 检查拖放的数据是否是文件夹
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            ' 允许拖放操作
            e.Effect = DragDropEffects.Copy
        Else
            ' 禁止拖放操作
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub TextBox2_DragDrop(sender As Object, e As DragEventArgs) Handles TextBox2.DragDrop
        ' 检查拖放的数据是否是文件
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            ' 获取拖放的文件路径
            Dim filePath As String = CType(e.Data.GetData(DataFormats.FileDrop), String())(0)

            ' 如果是文件路径，则在TextBox2中显示绝对路径
            If IO.File.Exists(filePath) Then
                TextBox2.Text = filePath
            End If
        End If
    End Sub

    Private Sub TextBox2_DragEnter(sender As Object, e As DragEventArgs) Handles TextBox2.DragEnter
        ' 检查拖放的数据是否是文件
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            ' 允许拖放操作
            e.Effect = DragDropEffects.Copy
        Else
            ' 禁止拖放操作
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If RadioButton1.Checked Then
            Dim folderPath As String = TextBox1.Text
            Dim newCreationTime As DateTime = DateTime.ParseExact(TextBox3.Text, "yyyy-MM-dd HH:mm:ss", Nothing)

            If Directory.Exists(folderPath) Then
                Directory.SetCreationTime(folderPath, newCreationTime)
            Else
                MessageBox.Show("指定的文件夹路径不存在。")
            End If
        ElseIf RadioButton2.Checked Then
            Dim filePath As String = TextBox2.Text
            Dim newCreationTime As DateTime = DateTime.ParseExact(TextBox3.Text, "yyyy-MM-dd HH:mm:ss", Nothing)
            Dim newModificationTime As DateTime = DateTime.ParseExact(TextBox4.Text, "yyyy-MM-dd HH:mm:ss", Nothing)

            If File.Exists(filePath) Then
                File.SetCreationTime(filePath, newCreationTime)
                File.SetLastWriteTime(filePath, newModificationTime)
            Else
                MessageBox.Show("指定的文件路径不存在。")
            End If
        Else
            MessageBox.Show("请选择一个选项。")
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        TextBox1.Clear()
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        TextBox2.Clear()
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        System.Diagnostics.Process.Start("http://mcenahle.com/2023/10/13/1/")
    End Sub

    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        System.Diagnostics.Process.Start("https://www.gnu.org/licenses/gpl-3.0.html")
    End Sub
End Class
